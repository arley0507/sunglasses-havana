import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAuthenticated } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'
export const maxDuration = 60

export async function POST(request: Request) {
  if (!(await isAuthenticated())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File | null
    if (!file) return NextResponse.json({ error: 'No file' }, { status: 400 })
    if (!file.type.startsWith('image/')) return NextResponse.json({ error: 'Solo imágenes' }, { status: 400 })
    if (file.size > 5 * 1024 * 1024) return NextResponse.json({ error: 'Máx 5MB' }, { status: 400 })
    const rawBuffer = Buffer.from(await file.arrayBuffer())
    let compressedBuffer: Buffer
    try {
      const sharp = (await import('sharp')).default
      compressedBuffer = await sharp(rawBuffer).resize(1200, 1200, { fit: 'inside', withoutEnlargement: true }).webp({ quality: 80 }).toBuffer()
    } catch { compressedBuffer = rawBuffer }
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 10)
    const filename = `${id}.webp`
    await db.uploadedImage.create({ data: { id, filename, mimeType: 'image/webp', size: compressedBuffer.length, data: compressedBuffer } })
    return NextResponse.json({ url: `/uploads/${filename}` })
  } catch (e) { return NextResponse.json({ error: 'Upload failed' }, { status: 500 }) }
}
